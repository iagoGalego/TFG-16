/**
 * Created by victorjose.gallego on 2/4/16.
 */
import TYPES from './types'

export function saveTask( task ){
    return {
        type: TYPES.SAVE_TASK,
        payload: task,
    }
}