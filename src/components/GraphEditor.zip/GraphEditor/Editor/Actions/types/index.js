/**
 * Created by victorjose.gallego on 2/4/16.
 */
export const TYPES = {
    SAVE_TASK : Symbol('SAVE_TASK'),
}

export default TYPES