/**
 * Editor component:
 *     + Props:
 *          - graph: the Workflow object
 *          - translator: function to translate the WF object to anything compatible with JointJS
 */

import React, {Component} from 'react'
import CSSModules from 'react-css-modules'
import { Scrollbars } from 'react-custom-scrollbars'

import { autobind } from 'core-decorators'

import joint from 'jointjs'
import { initializePaper, buildGraph } from './Utils'

import styles from './styles.scss'

@CSSModules(styles, {allowMultiple: true})
@autobind class Editor extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {
        this.__paper = initializePaper(this.__graphContainer, buildGraph(this.props.graph));

        joint.layout.DirectedGraph.layout(buildGraph(this.props.graph), { setLinkVertices: true })
    }

    shouldComponentUpdate(){
        return true
    }

    render() {
        return (
            <div ref = { element => this.__mainContainer = element }
                 styleName = 'mainContainer'>
                <Scrollbars universal ref = { element => this.__graphScrollContainer = element }
                            styleName = 'graphScrollContainer'
                            autoHeight
                            autoHeightMin={`calc(100vh - 112px)`}
                >
                    <div ref = { element => this.__graphContainer = element }>
                        <div ref = { element => this.__HTMLElementsContainer = element } ></div>
                    </div>
                </Scrollbars>
            </div>
        )
    }
}

export default Editor

/*
<div ref = { element => this.__mainContainer = element }
                 className = { this.props.className }
                 styleName = 'mainContainer' >
                <Scrollbars ref = { element => this.__graphScrollContainer = element } styleName = 'graphScrollContainer'>
                    <div ref = { element => this.__graphContainer = element } >
                        <div ref = { element => this.__HTMLElementsContainer = element } ></div>
                    </div>
                </Scrollbars>
            </div>
 */