import React, {Component} from 'react'
import CSSModules from 'react-css-modules'
import { injectIntl, defineMessages } from 'react-intl'
import { Card, CardTitle, CardText } from 'react-toolbox/lib/card'
import { IconButton } from 'react-toolbox/lib/button'
import Tooltip from 'react-toolbox/lib/tooltip'

import styles from './styles.scss'

const TooltipButton = Tooltip(IconButton)
const taskDialog = defineMessages({
    maximizeTooltip : {
        id : 'games.editor.graph.tasksDialog.tooltips.maximize',
        description : 'Graph editor - Tasks Dialog - Tooltips - Maximize',
        defaultMessage : 'Maximize'
    },
    minimizeTooltip: {
        id : 'games.editor.graph.tasksDialog.tooltips.minimize',
        description : 'Graph editor - Tasks Dialog - Tooltips - Minimize',
        defaultMessage : 'Minimize'
    }
})

const TaskDialog = ({className, minimized, dialogToggleHandler, intl: { formatMessage }}) =>
    <Card className = {className} styleName='taskDialog'>
        <CardTitle styleName='dialogControls'>
            <TooltipButton icon={ minimized ? 'launch' : 'system_update_alt'}
                           onClick = { dialogToggleHandler }
                           tooltip={formatMessage(minimized ? taskDialog.maximizeTooltip : taskDialog.minimizeTooltip)}
                           tooltipPosition='horizontal'
            />
        </CardTitle>

        { minimized
            ? null
            :
            <CardText>

            </CardText>
        }
    </Card>

export default injectIntl(CSSModules(TaskDialog, styles))